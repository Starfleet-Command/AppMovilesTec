import React, { Component } from 'react';
import {
    Container,
    Header,
    Content,
    Card,
    CardItem,
    Text,
    Body,
    Footer,
    FooterTab,
    Picker,
    Form,
    Button,
    Icon,
    Item,
    Input,
} from 'native-base';
import { View, Image, TextInput, TouchableOpacity, Linking } from 'react-native';
import styles, { IMAGE_HEIGHT, IMAGE_HEIGHT_SMALL } from './styles';

export default class Assistant extends Component {
    constructor(props) {
        super(props);


    }

    render() {

    }

}